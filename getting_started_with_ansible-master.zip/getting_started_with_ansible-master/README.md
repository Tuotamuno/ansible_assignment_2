# Getting started with Ansible

![Ansible Logo](https://www.learnlinux.tv/wp-content/uploads/2020/12/ansible-e1607524003363.png)

This repository contains code that was worked on during the "Getting started with Ansible" tutorial series.

You can view the entire series [here](https://www.youtube.com/playlist?list=PLT98CRl2KxKEUHie1m24-wkyHpEsa4Y70).
